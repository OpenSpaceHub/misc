This asset contains 3d obj files for the building in NYC (Manhattan).

The data was originally acquired from:
NYC DOITT
https://www1.nyc.gov/site/doitt/initiatives/3d-building.page

In the CITY GML format

This was converted to CityJSON using:

citygml-tools
https://github.com/citygml4j/citygml-tools

The CityJSON files where converted to obj using:
cjio
https://github.com/cityjson/cjio

Final modifications (i.e. centering the origin to a known building lat/long, fixing normals, etc) were done in Meshlab
https://www.meshlab.net/

